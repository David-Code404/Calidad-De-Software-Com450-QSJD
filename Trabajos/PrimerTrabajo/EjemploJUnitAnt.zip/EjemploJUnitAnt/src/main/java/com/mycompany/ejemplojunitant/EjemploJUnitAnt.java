/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplojunitant;

/**
 *
 * @author David-Code
 */
public class EjemploJUnitAnt {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
